import React from 'react';
import { ArrowRight, ArrowDown, Check, X } from 'lucide-react';
import { MathCrosswordPuzzle, formatLinearEquationString } from '../engine/mathCrosswordEngine';

interface OnboardingOverlayProps {
  puzzle: MathCrosswordPuzzle;
  targetPos: { row: number; col: number };
  step: number; // 0: Row highlight, 1: Col highlight, 2: Intersection solve
  darkMode: boolean;
  onNextStep: () => void;
  onDismiss: () => void;
  onApplyTutorialDigit: (digit: string) => void;
}

export const OnboardingOverlay: React.FC<OnboardingOverlayProps> = ({
  puzzle,
  targetPos,
  step,
  darkMode,
  onNextStep,
  onDismiss,
  onApplyTutorialDigit,
}) => {
  const { row, col } = targetPos;
  const targetCell = puzzle.cells[row]?.[col];
  if (!targetCell) return null;

  const rowValues = puzzle.cells[row].map((c, idx) =>
    idx === col ? '?' : c.isClue ? c.solution : c.userValue || '?'
  );
  const rowEqText = formatLinearEquationString(rowValues, puzzle.rowOps[row]);

  const colOpsForCol = puzzle.colOps.map((r) => r[col]);
  const colValues = puzzle.cells.map((r, idx) =>
    idx === row ? '?' : r[col].isClue ? r[col].solution : r[col].userValue || '?'
  );
  const colEqText = formatLinearEquationString(colValues, colOpsForCol);

  return (
    <div
      className={`w-full max-w-2xl mx-auto mb-3 rounded-xl border px-4 py-3 transition-all duration-150 ${
        darkMode
          ? 'bg-slate-900/95 border-amber-500/40 text-slate-100 shadow-lg shadow-black/40'
          : 'bg-white border-blue-500/40 text-slate-900 shadow-md shadow-slate-200/70'
      }`}
      role="region"
      aria-label="Interactive Level 1 Guide"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start sm:items-center gap-3">
          {/* Step Indicator Icon */}
          <div
            className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 font-mono text-xs font-bold ${
              step === 0
                ? darkMode
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-blue-50 text-blue-700 border border-blue-200'
                : step === 1
                ? darkMode
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : darkMode
                ? 'bg-amber-500 text-slate-950'
                : 'bg-blue-600 text-white'
            }`}
          >
            {step === 0 ? (
              <ArrowRight className="w-4 h-4" />
            ) : step === 1 ? (
              <ArrowDown className="w-4 h-4" />
            ) : (
              <span>{targetCell.solution}</span>
            )}
          </div>

          <div className="text-left">
            <div className="flex items-center gap-2 text-xs font-mono">
              <span
                className={
                  darkMode ? 'text-amber-400 font-semibold' : 'text-blue-600 font-semibold'
                }
              >
                Interactive Guide ({step + 1}/3)
              </span>
              <span className={darkMode ? 'text-slate-600' : 'text-slate-300'}>·</span>
              <span className={darkMode ? 'text-slate-400' : 'text-slate-500'}>
                {step === 0
                  ? `Horizontal Row ${row + 1} (Left to Right)`
                  : step === 1
                  ? `Intersecting Column ${col + 1} (Top to Bottom)`
                  : `Intersection Cell (Row ${row + 1}, Col ${col + 1})`}
              </span>
            </div>

            <p className="text-sm font-medium mt-0.5">
              {step === 0 && (
                <>
                  Highlighted Row {row + 1} reads left-to-right:{' '}
                  <span className="font-mono font-bold underline decoration-amber-500/60 underline-offset-4">
                    {rowEqText}
                  </span>
                </>
              )}
              {step === 1 && (
                <>
                  Intersecting Column {col + 1} reads top-to-bottom:{' '}
                  <span className="font-mono font-bold underline decoration-emerald-500/60 underline-offset-4">
                    {colEqText}
                  </span>
                </>
              )}
              {step === 2 && (
                <>
                  Both lines share this cell. Type{' '}
                  <span className="font-mono font-bold px-1.5 py-0.5 rounded bg-amber-500/20">
                    {targetCell.solution}
                  </span>{' '}
                  to satisfy Row {row + 1} and Column {col + 1} simultaneously.
                </>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          {step < 2 ? (
            <button
              type="button"
              onClick={onNextStep}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                darkMode
                  ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                  : 'bg-blue-600 text-white hover:bg-blue-500'
              }`}
            >
              <span>{step === 0 ? 'Show Column' : 'Show Intersection'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                onApplyTutorialDigit(String(targetCell.solution));
                onDismiss();
              }}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                darkMode
                  ? 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                  : 'bg-emerald-600 text-white hover:bg-emerald-500'
              }`}
            >
              <Check className="w-3.5 h-3.5" />
              <span>Fill {targetCell.solution} & Continue</span>
            </button>
          )}

          <button
            type="button"
            onClick={onDismiss}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              darkMode
                ? 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                : 'text-slate-400 hover:bg-slate-100 hover:text-slate-700'
            }`}
            aria-label="Dismiss guide"
            title="Dismiss guide"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
