import React, { useEffect, useRef } from 'react';
import { Play, RotateCcw, Sun, Moon, Volume2, VolumeX } from 'lucide-react';

interface TitleScreenProps {
  rating: number;
  level: number;
  darkMode: boolean;
  muted: boolean;
  overrideSize: number | null;
  onSelectOverrideSize: (size: number | null) => void;
  onStartGame: () => void;
  onResetProgress: () => void;
  onToggleDarkMode: () => void;
  onToggleMute: () => void;
}

interface FloatingGlyph {
  x: number;
  y: number;
  vx: number;
  vy: number;
  char: string;
  alpha: number;
  size: number;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  rating,
  level,
  darkMode,
  muted,
  overrideSize,
  onSelectOverrideSize,
  onStartGame,
  onResetProgress,
  onToggleDarkMode,
  onToggleMute,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Keyboard shortcut: Enter or Space starts the game
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        onStartGame();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onStartGame]);

  // Isolated 60fps atmospheric math lattice canvas loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let lastTime = performance.now();

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const symbols = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '−', '×', '÷', '='];
    const glyphs: FloatingGlyph[] = Array.from({ length: 34 }, (_, i) => ({
      x: (i * 197) % window.innerWidth,
      y: (i * 131) % window.innerHeight,
      vx: ((i % 2 === 0 ? 1 : -1) * (8 + (i % 5) * 3)),
      vy: -10 - (i % 4) * 4,
      char: symbols[i % symbols.length],
      alpha: 0.05 + (i % 4) * 0.025,
      size: 16 + (i % 3) * 6,
    }));

    let gridOffset = 0;

    const render = (now: number) => {
      const rawDt = (now - lastTime) / 1000;
      const dt = Math.min(rawDt, 0.05);
      lastTime = now;

      const w = window.innerWidth;
      const h = window.innerHeight;

      ctx.clearRect(0, 0, w, h);

      // Subtle architectural blueprint grid
      gridOffset = (gridOffset + dt * 12) % 64;
      ctx.strokeStyle = darkMode ? 'rgba(148, 163, 184, 0.055)' : 'rgba(15, 23, 42, 0.045)';
      ctx.lineWidth = 1;

      const step = 64;
      for (let x = -step + (gridOffset % step); x < w; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = -step + (gridOffset % step); y < h; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Floating mathematical glyphs
      ctx.font = '600 18px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      for (const g of glyphs) {
        g.x += g.vx * dt;
        g.y += g.vy * dt;
        if (g.x < -40) g.x = w + 40;
        if (g.x > w + 40) g.x = -40;
        if (g.y < -40) g.y = h + 40;

        ctx.fillStyle = darkMode
          ? `rgba(245, 158, 11, ${g.alpha})`
          : `rgba(37, 99, 235, ${g.alpha})`;
        ctx.font = `600 ${g.size}px "JetBrains Mono", monospace`;
        ctx.fillText(g.char, g.x, g.y);
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, [darkMode]);

  const gridSizes = [
    { label: 'Adaptive', value: null },
    { label: '3×3', value: 3 },
    { label: '4×4', value: 4 },
    { label: '5×5', value: 5 },
    { label: '6×6', value: 6 },
    { label: '7×7', value: 7 },
  ];

  return (
    <div
      className={`relative w-screen h-dvh overflow-hidden select-none flex flex-col justify-between transition-colors duration-200 ${
        darkMode ? 'bg-[#0B0F17] text-slate-100' : 'bg-[#F8FAFC] text-slate-900'
      }`}
    >
      {/* Isolated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
      />

      {/* Perimeter Top Bar Controls */}
      <div className="relative z-10 flex items-center justify-between px-6 py-5 max-w-6xl w-full mx-auto">
        <div className="flex items-center gap-3 text-xs font-mono tabular-nums tracking-wider">
          <span className={darkMode ? 'text-slate-400' : 'text-slate-600'}>
            LEVEL {level}
          </span>
          <span className={darkMode ? 'text-slate-600' : 'text-slate-300'}>·</span>
          <span className={darkMode ? 'text-amber-400' : 'text-blue-600'}>
            RATING {rating}
          </span>
          {level > 1 && (
            <>
              <span className={darkMode ? 'text-slate-600' : 'text-slate-300'}>·</span>
              <button
                type="button"
                onClick={onResetProgress}
                className={`inline-flex items-center gap-1.5 underline-offset-4 hover:underline cursor-pointer transition-colors ${
                  darkMode ? 'text-slate-400 hover:text-slate-200' : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Reset to Level 1 (Rating 100)"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Campaign</span>
              </button>
            </>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleMute}
            className={`p-2.5 rounded-lg border transition-colors cursor-pointer ${
              darkMode
                ? 'border-slate-800 bg-slate-900/70 text-slate-300 hover:bg-slate-800 hover:text-white'
                : 'border-slate-200 bg-white/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
            aria-label={muted ? 'Unmute audio' : 'Mute audio'}
            title={muted ? 'Unmute audio' : 'Mute audio'}
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={onToggleDarkMode}
            className={`p-2.5 rounded-lg border transition-colors cursor-pointer ${
              darkMode
                ? 'border-slate-800 bg-slate-900/70 text-slate-300 hover:bg-slate-800 hover:text-white'
                : 'border-slate-200 bg-white/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
            aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
            title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Center Hero Lockup over generous negative space */}
      <div className="relative z-10 flex flex-col items-center justify-center px-6 text-center max-w-2xl mx-auto my-auto">
        {/* Bespoke Inline SVG Geometric Crossword Emblem & Lockup */}
        <div className="mb-6">
          <svg
            width="84"
            height="84"
            viewBox="0 0 84 84"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="mx-auto"
            aria-hidden="true"
          >
            <rect
              x="6"
              y="6"
              width="28"
              height="28"
              rx="6"
              className={darkMode ? 'stroke-amber-400 fill-amber-500/10' : 'stroke-blue-600 fill-blue-500/10'}
              strokeWidth="2.2"
            />
            <rect
              x="50"
              y="6"
              width="28"
              height="28"
              rx="6"
              className={darkMode ? 'stroke-slate-600 fill-slate-900/80' : 'stroke-slate-300 fill-white'}
              strokeWidth="2"
            />
            <rect
              x="6"
              y="50"
              width="28"
              height="28"
              rx="6"
              className={darkMode ? 'stroke-slate-600 fill-slate-900/80' : 'stroke-slate-300 fill-white'}
              strokeWidth="2"
            />
            <rect
              x="50"
              y="50"
              width="28"
              height="28"
              rx="6"
              className={darkMode ? 'stroke-emerald-400 fill-emerald-500/10' : 'stroke-emerald-600 fill-emerald-500/10'}
              strokeWidth="2.2"
            />
            {/* Horizontal and vertical operator connectors */}
            <path
              d="M38 20H46M42 16V24"
              className={darkMode ? 'stroke-amber-400' : 'stroke-blue-600'}
              strokeWidth="2.2"
              strokeLinecap="round"
            />
            <path
              d="M16 42H24M16 42H24"
              className={darkMode ? 'stroke-slate-400' : 'stroke-slate-500'}
              strokeWidth="2.2"
              strokeLinecap="round"
            />
            <path
              d="M60 40H68M60 44H68"
              className={darkMode ? 'stroke-emerald-400' : 'stroke-emerald-600'}
              strokeWidth="2.2"
              strokeLinecap="round"
            />
            <path
              d="M38 62H46M38 66H46"
              className={darkMode ? 'stroke-emerald-400' : 'stroke-emerald-600'}
              strokeWidth="2.2"
              strokeLinecap="round"
            />
            <text
              x="20"
              y="25"
              textAnchor="middle"
              className={`font-mono text-sm font-bold ${darkMode ? 'fill-amber-300' : 'fill-blue-700'}`}
            >
              3
            </text>
            <text
              x="64"
              y="25"
              textAnchor="middle"
              className={`font-mono text-sm font-bold ${darkMode ? 'fill-slate-200' : 'fill-slate-700'}`}
            >
              4
            </text>
            <text
              x="20"
              y="69"
              textAnchor="middle"
              className={`font-mono text-sm font-bold ${darkMode ? 'fill-slate-200' : 'fill-slate-700'}`}
            >
              2
            </text>
            <text
              x="64"
              y="69"
              textAnchor="middle"
              className={`font-mono text-sm font-bold ${darkMode ? 'fill-emerald-300' : 'fill-emerald-700'}`}
            >
              7
            </text>
          </svg>
        </div>

        <h1
          className="font-display text-5xl sm:text-6xl font-bold tracking-tight mb-4"
          style={{ textWrap: 'balance' }}
        >
          Arithmos
        </h1>

        <p
          className={`text-base sm:text-lg max-w-lg mx-auto mb-8 leading-relaxed ${
            darkMode ? 'text-slate-300' : 'text-slate-600'
          }`}
        >
          Procedural mathematical crossword logic. Every intersecting row and column evaluates strictly left-to-right and top-to-bottom with a single verified unique solution.
        </p>

        {/* Grid Scale Mode Selector */}
        <div className="mb-8 flex flex-col items-center gap-2">
          <span className={`text-xs font-medium ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Grid Scaling Mode
          </span>
          <div
            className={`inline-flex items-center gap-1 p-1 rounded-lg border ${
              darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-slate-100 border-slate-200'
            }`}
          >
            {gridSizes.map((item) => {
              const active = overrideSize === item.value;
              return (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => onSelectOverrideSize(item.value)}
                  className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? darkMode
                        ? 'bg-amber-500 text-slate-950 font-semibold'
                        : 'bg-blue-600 text-white font-semibold'
                      : darkMode
                      ? 'text-slate-400 hover:text-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Primary Start Game CTA */}
        <button
          type="button"
          onClick={onStartGame}
          className={`group inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl text-base font-semibold transition-all duration-150 cursor-pointer shadow-lg ${
            darkMode
              ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-amber-500/15'
              : 'bg-blue-600 text-white hover:bg-blue-500 shadow-blue-600/20'
          }`}
        >
          <Play className="w-5 h-5 fill-current" />
          <span className="whitespace-nowrap shrink-0">
            {level === 1 && !overrideSize ? 'Start Level 1 (3×3)' : `Start Level ${level}`}
          </span>
        </button>
      </div>

      {/* Single flat control-hint line at bottom */}
      <div className="relative z-10 px-6 py-5 text-center">
        <p
          className={`text-xs font-mono tracking-wide ${
            darkMode ? 'text-slate-500' : 'text-slate-500'
          }`}
        >
          0–9 Input Digit · Arrows Navigate · Tab Switch Axis · Space Hint · Enter Check
        </p>
      </div>
    </div>
  );
};
