/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  Lightbulb,
  RefreshCw,
  CheckCircle2,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Pause,
  Play,
  ArrowRight,
  ArrowDown,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  Delete,
  HelpCircle,
  Award,
  TrendingUp,
  Clock,
  Home,
} from 'lucide-react';
import {
  MathCrosswordPuzzle,
  MathOperator,
  RatingAdjustmentResult,
  generateMathCrossword,
  isCompleteLineValid,
  formatLinearEquationString,
  findLogicalDeductionHint,
  calculateRatingAdjustment,
} from './engine/mathCrosswordEngine';
import { soundEngine } from './utils/soundEngine';
import { TitleScreen } from './components/TitleScreen';
import { OnboardingOverlay } from './components/OnboardingOverlay';

type GameState = 'TITLE_MENU' | 'PLAYING' | 'PAUSED' | 'ROUND_SUMMARY';

interface SavedProgress {
  rating: number;
  level: number;
  darkMode: boolean;
}

const STORAGE_KEY = 'arithmos_progress_v1';

function loadSavedProgress(): SavedProgress {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        rating: typeof parsed.rating === 'number' && parsed.rating >= 100 ? parsed.rating : 100,
        level: typeof parsed.level === 'number' && parsed.level >= 1 ? parsed.level : 1,
        darkMode: typeof parsed.darkMode === 'boolean' ? parsed.darkMode : true,
      };
    }
  } catch {
    // Ignore storage read errors
  }
  return { rating: 100, level: 1, darkMode: true };
}

export default function App() {
  const initialProgress = useMemo(() => loadSavedProgress(), []);

  const [gameState, setGameState] = useState<GameState>('TITLE_MENU');
  const [rating, setRating] = useState<number>(initialProgress.rating);
  const [level, setLevel] = useState<number>(initialProgress.level);
  const [darkMode, setDarkMode] = useState<boolean>(initialProgress.darkMode);
  const [muted, setMuted] = useState<boolean>(() => soundEngine.isMuted());
  const [overrideSize, setOverrideSize] = useState<number | null>(null);

  const [puzzle, setPuzzle] = useState<MathCrosswordPuzzle>(() =>
    generateMathCrossword(initialProgress.rating, initialProgress.level, null)
  );

  // Active cell focus and traversal direction ('row' = horizontal, 'col' = vertical)
  const [focusedPos, setFocusedPos] = useState<{ row: number; col: number } | null>(null);
  const [direction, setDirection] = useState<'row' | 'col'>('row');

  // Level metrics
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [hintsUsed, setHintsUsed] = useState<number>(0);
  const [errorsMade, setErrorsMade] = useState<number>(0);
  const [statusBanner, setStatusBanner] = useState<{
    type: 'info' | 'error' | 'success';
    message: string;
  } | null>(null);
  const [lastRatingResult, setLastRatingResult] = useState<RatingAdjustmentResult | null>(null);

  // Interactive onboarding state for Level 1
  const [showOnboarding, setShowOnboarding] = useState<boolean>(false);
  const [onboardingStep, setOnboardingStep] = useState<number>(0);

  // Matrix of refs for input focus tracking
  const inputRefs = useRef<(HTMLInputElement | null)[][]>([]);

  // Persist progress changes
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ rating, level, darkMode })
      );
    } catch {
      // Ignore storage write errors
    }
  }, [rating, level, darkMode]);

  // Find the first editable cell in a puzzle
  const findFirstEditableCell = useCallback(
    (p: MathCrosswordPuzzle): { row: number; col: number } | null => {
      for (let r = 0; r < p.size; r++) {
        for (let c = 0; c < p.size; c++) {
          if (!p.cells[r][c].isClue) {
            return { row: r, col: c };
          }
        }
      }
      return null;
    },
    []
  );

  // Start or load a new puzzle
  const startPuzzleLevel = useCallback(
    (targetRating: number, targetLevel: number, sizeOverride: number | null) => {
      const newPuzzle = generateMathCrossword(targetRating, targetLevel, sizeOverride);
      setPuzzle(newPuzzle);
      setElapsedSeconds(0);
      setHintsUsed(0);
      setErrorsMade(0);
      setStatusBanner(null);
      setLastRatingResult(null);
      setDirection('row');

      const firstCell = findFirstEditableCell(newPuzzle);
      setFocusedPos(firstCell);

      if (targetLevel === 1 && !sizeOverride) {
        setShowOnboarding(true);
        setOnboardingStep(0);
      } else {
        setShowOnboarding(false);
      }

      setGameState('PLAYING');

      setTimeout(() => {
        if (firstCell && inputRefs.current[firstCell.row]?.[firstCell.col]) {
          inputRefs.current[firstCell.row][firstCell.col]?.focus();
        }
      }, 40);
    },
    [findFirstEditableCell]
  );

  // Timer tick while playing
  useEffect(() => {
    if (gameState !== 'PLAYING') return;
    const interval = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [gameState]);

  // Evaluate whether each row and column is currently complete and valid
  const lineStatuses = useMemo(() => {
    const N = puzzle.size;
    const rowValid: ('incomplete' | 'valid' | 'invalid')[] = new Array(N).fill('incomplete');
    const colValid: ('incomplete' | 'valid' | 'invalid')[] = new Array(N).fill('incomplete');

    for (let r = 0; r < N; r++) {
      const vals: number[] = [];
      let complete = true;
      for (let c = 0; c < N; c++) {
        const raw = puzzle.cells[r][c].isClue
          ? puzzle.cells[r][c].solution
          : parseInt(puzzle.cells[r][c].userValue, 10);
        if (!Number.isInteger(raw) || raw < 1) {
          complete = false;
          break;
        }
        vals.push(raw);
      }
      if (complete) {
        rowValid[r] = isCompleteLineValid(vals, puzzle.rowOps[r]) ? 'valid' : 'invalid';
      }
    }

    for (let c = 0; c < N; c++) {
      const vals: number[] = [];
      let complete = true;
      for (let r = 0; r < N; r++) {
        const raw = puzzle.cells[r][c].isClue
          ? puzzle.cells[r][c].solution
          : parseInt(puzzle.cells[r][c].userValue, 10);
        if (!Number.isInteger(raw) || raw < 1) {
          complete = false;
          break;
        }
        vals.push(raw);
      }
      if (complete) {
        const cOps: MathOperator[] = [];
        for (let r = 0; r < N - 2; r++) cOps.push(puzzle.colOps[r][c]);
        colValid[c] = isCompleteLineValid(vals, cOps) ? 'valid' : 'invalid';
      }
    }

    return { rowValid, colValid };
  }, [puzzle]);

  // Find the next empty intersecting cell after (row, col)
  const findNextEmptyIntersectingCell = useCallback(
    (
      currentPuzzle: MathCrosswordPuzzle,
      fromRow: number,
      fromCol: number,
      preferredDir: 'row' | 'col'
    ): { row: number; col: number; newDir?: 'row' | 'col' } | null => {
      const N = currentPuzzle.size;
      const isCellEmpty = (r: number, c: number) =>
        !currentPuzzle.cells[r][c].isClue && currentPuzzle.cells[r][c].userValue.trim() === '';

      // 1. Check remaining cells along the active line in preferredDir
      if (preferredDir === 'row') {
        for (let offset = 1; offset < N; offset++) {
          const nextC = (fromCol + offset) % N;
          if (isCellEmpty(fromRow, nextC)) {
            return { row: fromRow, col: nextC };
          }
        }
        // 2. Check the intersecting column at fromCol
        for (let offset = 1; offset < N; offset++) {
          const nextR = (fromRow + offset) % N;
          if (isCellEmpty(nextR, fromCol)) {
            return { row: nextR, col: fromCol, newDir: 'col' };
          }
        }
      } else {
        for (let offset = 1; offset < N; offset++) {
          const nextR = (fromRow + offset) % N;
          if (isCellEmpty(nextR, fromCol)) {
            return { row: nextR, col: fromCol };
          }
        }
        // 2. Check the intersecting row at fromRow
        for (let offset = 1; offset < N; offset++) {
          const nextC = (fromCol + offset) % N;
          if (isCellEmpty(fromRow, nextC)) {
            return { row: fromRow, col: nextC, newDir: 'row' };
          }
        }
      }

      // 3. Scan the rest of the board in reading order
      const total = N * N;
      const startIndex = fromRow * N + fromCol;
      for (let i = 1; i < total; i++) {
        const idx = (startIndex + i) % total;
        const r = Math.floor(idx / N);
        const c = idx % N;
        if (isCellEmpty(r, c)) {
          return { row: r, col: c };
        }
      }

      return null;
    },
    []
  );

  const focusCell = useCallback((row: number, col: number) => {
    setFocusedPos({ row, col });
    setTimeout(() => {
      inputRefs.current[row]?.[col]?.focus();
    }, 10);
  }, []);

  // Check if entire board is solved
  const checkVictoryIfComplete = useCallback(
    (updatedPuzzle: MathCrosswordPuzzle, currentHints: number, currentErrors: number) => {
      const N = updatedPuzzle.size;

      // Verify all cells are filled with positive integers
      for (let r = 0; r < N; r++) {
        for (let c = 0; c < N; c++) {
          const cell = updatedPuzzle.cells[r][c];
          if (!cell.isClue) {
            const val = parseInt(cell.userValue, 10);
            if (!Number.isInteger(val) || val < 1) return false;
          }
        }
      }

      // Verify all N row equations and N column equations hold
      for (let r = 0; r < N; r++) {
        const rowVals = updatedPuzzle.cells[r].map((cl) =>
          cl.isClue ? cl.solution : parseInt(cl.userValue, 10)
        );
        if (!isCompleteLineValid(rowVals, updatedPuzzle.rowOps[r])) return false;
      }

      for (let c = 0; c < N; c++) {
        const colVals = updatedPuzzle.cells.map((rowArr) =>
          rowArr[c].isClue ? rowArr[c].solution : parseInt(rowArr[c].userValue, 10)
        );
        const cOps: MathOperator[] = [];
        for (let r = 0; r < N - 2; r++) cOps.push(updatedPuzzle.colOps[r][c]);
        if (!isCompleteLineValid(colVals, cOps)) return false;
      }

      // Puzzle solved! Compute adaptive rating progression
      soundEngine.playVictory();
      const ratingAdj = calculateRatingAdjustment(
        rating,
        elapsedSeconds,
        updatedPuzzle.profile.parTimeSeconds,
        currentHints,
        currentErrors
      );
      setLastRatingResult(ratingAdj);
      setRating(ratingAdj.newRating);
      setShowOnboarding(false);
      setGameState('ROUND_SUMMARY');
      return true;
    },
    [rating, elapsedSeconds]
  );

  // Handle cell digit input change
  const handleCellInputChange = useCallback(
    (row: number, col: number, rawInput: string) => {
      const cell = puzzle.cells[row]?.[col];
      if (!cell || cell.isClue) return;

      // Only accept numerical digits (strip non-digits and leading zeros)
      const digitsOnly = rawInput.replace(/[^0-9]/g, '');
      const cleanVal = digitsOnly.replace(/^0+/, '').slice(0, 2);

      soundEngine.playTick(cleanVal ? parseInt(cleanVal, 10) % 7 : 0);
      setStatusBanner(null);

      const nextCells = puzzle.cells.map((rArr, rIdx) =>
        rArr.map((cObj, cIdx) => {
          if (rIdx === row && cIdx === col) {
            return {
              ...cObj,
              userValue: cleanVal,
              isError: false,
            };
          }
          return cObj;
        })
      );

      const updatedPuzzle: MathCrosswordPuzzle = {
        ...puzzle,
        cells: nextCells,
      };
      setPuzzle(updatedPuzzle);

      // If Level 1 onboarding is active and player typed the right answer on target cell, dismiss guide
      if (showOnboarding && parseInt(cleanVal, 10) === cell.solution) {
        setShowOnboarding(false);
      }

      // Check if puzzle is now completely solved
      const won = checkVictoryIfComplete(updatedPuzzle, hintsUsed, errorsMade);
      if (won) return;

      // Auto-advance focus to next empty intersecting cell when the expected digit length is reached
      const expectedLength = String(cell.solution).length;
      if (cleanVal.length >= expectedLength) {
        // Check if completing this cell just balanced its row or column
        const rowFilled = updatedPuzzle.cells[row].every(
          (cl) => cl.isClue || cl.userValue.trim() !== ''
        );
        if (rowFilled) {
          const rVals = updatedPuzzle.cells[row].map((cl) =>
            cl.isClue ? cl.solution : parseInt(cl.userValue, 10)
          );
          if (isCompleteLineValid(rVals, updatedPuzzle.rowOps[row])) {
            soundEngine.playEquationSolved();
          }
        }

        const nextTarget = findNextEmptyIntersectingCell(
          updatedPuzzle,
          row,
          col,
          direction
        );
        if (nextTarget) {
          if (nextTarget.newDir) {
            setDirection(nextTarget.newDir);
          }
          focusCell(nextTarget.row, nextTarget.col);
        }
      }
    },
    [
      puzzle,
      direction,
      hintsUsed,
      errorsMade,
      showOnboarding,
      checkVictoryIfComplete,
      findNextEmptyIntersectingCell,
      focusCell,
    ]
  );

  // Trigger a smart hint on the next logical cell
  const handleTriggerHint = useCallback(() => {
    if (gameState !== 'PLAYING') return;
    const deduction = findLogicalDeductionHint(puzzle, focusedPos);
    if (!deduction) return;

    soundEngine.playHint();
    const newHintsUsed = hintsUsed + 1;
    setHintsUsed(newHintsUsed);

    const nextCells = puzzle.cells.map((rArr, rIdx) =>
      rArr.map((cObj, cIdx) => {
        if (rIdx === deduction.row && cIdx === deduction.col) {
          return {
            ...cObj,
            userValue: String(deduction.value),
            isHinted: true,
            isError: false,
          };
        }
        return cObj;
      })
    );

    const updatedPuzzle: MathCrosswordPuzzle = {
      ...puzzle,
      cells: nextCells,
    };
    setPuzzle(updatedPuzzle);
    setStatusBanner({
      type: 'info',
      message: deduction.explanation,
    });

    const won = checkVictoryIfComplete(updatedPuzzle, newHintsUsed, errorsMade);
    if (!won) {
      const nextTarget = findNextEmptyIntersectingCell(
        updatedPuzzle,
        deduction.row,
        deduction.col,
        direction
      );
      if (nextTarget) {
        focusCell(nextTarget.row, nextTarget.col);
      } else {
        focusCell(deduction.row, deduction.col);
      }
    }
  }, [
    gameState,
    puzzle,
    focusedPos,
    hintsUsed,
    errorsMade,
    direction,
    checkVictoryIfComplete,
    findNextEmptyIntersectingCell,
    focusCell,
  ]);

  // Validate current entries against unique solution
  const handleValidateBoard = useCallback(() => {
    if (gameState !== 'PLAYING') return;

    let errorCount = 0;
    let emptyCount = 0;

    const nextCells = puzzle.cells.map((rArr) =>
      rArr.map((cell) => {
        if (cell.isClue) return cell;
        if (cell.userValue.trim() === '') {
          emptyCount++;
          return { ...cell, isError: false };
        }
        const parsed = parseInt(cell.userValue, 10);
        const wrong = parsed !== cell.solution;
        if (wrong) errorCount++;
        return { ...cell, isError: wrong };
      })
    );

    const updatedPuzzle = { ...puzzle, cells: nextCells };
    setPuzzle(updatedPuzzle);

    if (errorCount > 0) {
      soundEngine.playError();
      setErrorsMade((prev) => prev + errorCount);
      setStatusBanner({
        type: 'error',
        message: `${errorCount} cell${errorCount > 1 ? 's' : ''} highlighted in red do not satisfy the intersecting equations.`,
      });
    } else if (emptyCount > 0) {
      soundEngine.playTick(2);
      setStatusBanner({
        type: 'info',
        message: `All entered digits are accurate so far. ${emptyCount} cell${
          emptyCount > 1 ? 's' : ''
        } remaining.`,
      });
    } else {
      checkVictoryIfComplete(updatedPuzzle, hintsUsed, errorsMade);
    }
  }, [gameState, puzzle, hintsUsed, errorsMade, checkVictoryIfComplete]);

  // Keyboard navigation across the crossword grid
  const handleCellKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>,
    row: number,
    col: number
  ) => {
    const N = puzzle.size;

    if (e.key === 'Escape') {
      e.preventDefault();
      setGameState((prev) => (prev === 'PLAYING' ? 'PAUSED' : 'PLAYING'));
      return;
    }

    if (e.key === 'Tab') {
      e.preventDefault();
      setDirection((prev) => (prev === 'row' ? 'col' : 'row'));
      soundEngine.playTick(1);
      return;
    }

    if (e.key === ' ') {
      e.preventDefault();
      handleTriggerHint();
      return;
    }

    if (e.key === 'Enter') {
      e.preventDefault();
      handleValidateBoard();
      return;
    }

    if (e.key === 'Backspace' && puzzle.cells[row][col].userValue === '') {
      e.preventDefault();
      // Step backward along current direction to previous editable cell
      for (let step = 1; step < N * N; step++) {
        let prevR = row;
        let prevC = col;
        if (direction === 'row') {
          const flat = (row * N + col - step + N * N) % (N * N);
          prevR = Math.floor(flat / N);
          prevC = flat % N;
        } else {
          const flat = (col * N + row - step + N * N) % (N * N);
          prevC = Math.floor(flat / N);
          prevR = flat % N;
        }
        if (!puzzle.cells[prevR][prevC].isClue) {
          focusCell(prevR, prevC);
          break;
        }
      }
      return;
    }

    const moveFocusDelta = (dr: number, dc: number, newDir: 'row' | 'col') => {
      e.preventDefault();
      setDirection(newDir);
      let currR = row;
      let currC = col;
      for (let i = 0; i < N * N; i++) {
        currR = (currR + dr + N) % N;
        currC = (currC + dc + N) % N;
        if (!puzzle.cells[currR][currC].isClue) {
          focusCell(currR, currC);
          return;
        }
      }
    };

    if (e.key === 'ArrowRight') {
      moveFocusDelta(0, 1, 'row');
    } else if (e.key === 'ArrowLeft') {
      moveFocusDelta(0, -1, 'row');
    } else if (e.key === 'ArrowDown') {
      moveFocusDelta(1, 0, 'col');
    } else if (e.key === 'ArrowUp') {
      moveFocusDelta(-1, 0, 'col');
    }
  };

  // Handle on-screen numpad digit click
  const handleNumpadPress = (digit: string) => {
    if (!focusedPos) return;
    const cell = puzzle.cells[focusedPos.row]?.[focusedPos.col];
    if (!cell || cell.isClue) return;

    if (digit === 'BACKSPACE') {
      const nextVal = cell.userValue.slice(0, -1);
      handleCellInputChange(focusedPos.row, focusedPos.col, nextVal);
      focusCell(focusedPos.row, focusedPos.col);
      return;
    }

    const expectedLen = String(cell.solution).length;
    const currentVal = cell.userValue.length >= expectedLen ? '' : cell.userValue;
    handleCellInputChange(focusedPos.row, focusedPos.col, currentVal + digit);
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  };

  const displayOperatorSymbol = (op: MathOperator) => {
    switch (op) {
      case '+':
        return '+';
      case '-':
        return '−';
      case '*':
        return '×';
      case '/':
        return '÷';
    }
  };

  // Active row & column linear equations for the live Equation Inspector bar
  const activeEquationsPreview = useMemo(() => {
    const pos = focusedPos || { row: 0, col: 0 };
    const r = Math.min(pos.row, puzzle.size - 1);
    const c = Math.min(pos.col, puzzle.size - 1);

    const rowValues = puzzle.cells[r].map((cell) =>
      cell.isClue ? cell.solution : cell.userValue || '?'
    );
    const rowString = formatLinearEquationString(rowValues, puzzle.rowOps[r]);

    const colValues = puzzle.cells.map((rowArr) => {
      const cell = rowArr[c];
      return cell.isClue ? cell.solution : cell.userValue || '?';
    });
    const cOps: MathOperator[] = [];
    for (let i = 0; i < puzzle.size - 2; i++) cOps.push(puzzle.colOps[i][c]);
    const colString = formatLinearEquationString(colValues, cOps);

    return {
      rowIndex: r,
      colIndex: c,
      rowString,
      colString,
    };
  }, [focusedPos, puzzle]);

  if (gameState === 'TITLE_MENU') {
    return (
      <TitleScreen
        rating={rating}
        level={level}
        darkMode={darkMode}
        muted={muted}
        overrideSize={overrideSize}
        onSelectOverrideSize={setOverrideSize}
        onStartGame={() => startPuzzleLevel(rating, level, overrideSize)}
        onResetProgress={() => {
          setRating(100);
          setLevel(1);
          setOverrideSize(null);
          startPuzzleLevel(100, 1, null);
        }}
        onToggleDarkMode={() => setDarkMode((d) => !d)}
        onToggleMute={() => setMuted(soundEngine.toggleMute())}
      />
    );
  }

  const N = puzzle.size;

  // Dynamic sizing of cells based on grid dimension N (from 3x3 up to 7x7)
  const cellDimClass =
    N === 3
      ? 'w-14 h-14 sm:w-18 sm:h-18 text-xl sm:text-2xl'
      : N === 4
      ? 'w-12 h-12 sm:w-15 sm:h-15 text-lg sm:text-xl'
      : N === 5
      ? 'w-10 h-10 sm:w-13 sm:h-13 text-base sm:text-lg'
      : N === 6
      ? 'w-9 h-9 sm:w-11 sm:h-11 text-sm sm:text-base'
      : 'w-8 h-8 sm:w-10 sm:h-10 text-xs sm:text-sm';

  const opCellWidthClass =
    N === 3
      ? 'w-7 sm:w-9 text-base sm:text-lg'
      : N === 4
      ? 'w-6 sm:w-8 text-sm sm:text-base'
      : N <= 5
      ? 'w-5 sm:w-7 text-xs sm:text-sm'
      : 'w-4 sm:w-6 text-xs';

  const opRowHeightClass =
    N === 3
      ? 'h-7 sm:h-9 text-base sm:text-lg'
      : N === 4
      ? 'h-6 sm:h-8 text-sm sm:text-base'
      : N <= 5
      ? 'h-5 sm:h-7 text-xs sm:text-sm'
      : 'h-4 sm:h-6 text-xs';

  return (
    <div
      className={`min-h-dvh w-screen flex flex-col justify-between transition-colors duration-200 select-none ${
        darkMode ? 'bg-[#0B0F17] text-slate-100' : 'bg-[#F8FAFC] text-slate-900'
      }`}
    >
      {/* Top Perimeter HUD */}
      <header
        className={`w-full border-b px-4 sm:px-6 py-3 transition-colors ${
          darkMode
            ? 'bg-[#0F1624]/90 border-slate-800/80'
            : 'bg-white/90 border-slate-200'
        }`}
      >
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
          {/* Left: Brand & Level/Rating Telemetry */}
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setGameState('TITLE_MENU')}
              className={`font-display text-lg font-bold tracking-tight transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                darkMode ? 'text-white hover:text-amber-400' : 'text-slate-900 hover:text-blue-600'
              }`}
              title="Return to Title Screen"
            >
              Arithmos
            </button>

            <div
              className={`hidden sm:flex items-center gap-2.5 text-xs font-mono tabular-nums ${
                darkMode ? 'text-slate-400' : 'text-slate-600'
              }`}
            >
              <span>Level {level}</span>
              <span aria-hidden="true">·</span>
              <span>
                {puzzle.size}×{puzzle.size} {puzzle.profile.tierName}
              </span>
              <span aria-hidden="true">·</span>
              <span className={darkMode ? 'text-amber-400 font-semibold' : 'text-blue-600 font-semibold'}>
                Rating {rating}
              </span>
              <span aria-hidden="true">·</span>
              <span
                className="inline-flex items-center gap-1"
                title="Verified by internal backtracking solver: 1 unique logical solution"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                <span>Unique Solution Verified</span>
              </span>
            </div>
          </div>

          {/* Center/Right: Timer & Action Controls */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Timer Readout */}
            <div
              className={`px-3 py-1.5 rounded-lg border font-mono text-xs sm:text-sm font-semibold tabular-nums flex items-center gap-1.5 ${
                darkMode
                  ? 'bg-slate-900 border-slate-800 text-slate-200'
                  : 'bg-slate-100 border-slate-200 text-slate-800'
              }`}
            >
              <Clock className="w-3.5 h-3.5 opacity-70" />
              <span>{formatTime(elapsedSeconds)}</span>
            </div>

            {/* Hint Button */}
            <button
              type="button"
              onClick={handleTriggerHint}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                darkMode
                  ? 'border-amber-500/40 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20'
                  : 'border-amber-300 bg-amber-50 text-amber-800 hover:bg-amber-100'
              }`}
              title="Reveal next single-unknown deduction (Space)"
            >
              <Lightbulb className="w-3.5 h-3.5" />
              <span>Hint ({hintsUsed})</span>
            </button>

            {/* Check Board Button */}
            <button
              type="button"
              onClick={handleValidateBoard}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                darkMode
                  ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20'
                  : 'border-emerald-300 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
              }`}
              title="Check current numbers (Enter)"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Check</span>
            </button>

            {/* New Puzzle / Regenerate */}
            <button
              type="button"
              onClick={() => startPuzzleLevel(rating, level, overrideSize)}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                darkMode
                  ? 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
              }`}
              title="Generate fresh puzzle at current rating"
              aria-label="Generate new puzzle"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {/* Guide Toggle */}
            <button
              type="button"
              onClick={() => {
                setShowOnboarding((prev) => !prev);
                setOnboardingStep(0);
              }}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                showOnboarding
                  ? darkMode
                    ? 'border-amber-500 bg-amber-500/20 text-amber-300'
                    : 'border-blue-500 bg-blue-50 text-blue-700'
                  : darkMode
                  ? 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
              }`}
              title="Toggle Interactive Visual Guide"
              aria-label="Toggle interactive guide"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            {/* Mute Toggle */}
            <button
              type="button"
              onClick={() => setMuted(soundEngine.toggleMute())}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                darkMode
                  ? 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
              }`}
              title={muted ? 'Unmute audio' : 'Mute audio'}
              aria-label={muted ? 'Unmute audio' : 'Mute audio'}
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* Dark/Light Mode Toggle */}
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                darkMode
                  ? 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
              }`}
              title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
              aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Pause Button */}
            <button
              type="button"
              onClick={() => setGameState('PAUSED')}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                darkMode
                  ? 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-100'
              }`}
              title="Pause & Settings (Esc)"
              aria-label="Pause game"
            >
              <Pause className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Playfield Workspace */}
      <main className="flex-1 flex flex-col items-center justify-center px-3 sm:px-6 py-4 max-w-6xl w-full mx-auto">
        {/* Interactive Onboarding Guide on Level 1 (or when toggled) */}
        {showOnboarding && focusedPos && (
          <OnboardingOverlay
            puzzle={puzzle}
            targetPos={focusedPos}
            step={onboardingStep}
            darkMode={darkMode}
            onNextStep={() => setOnboardingStep((s) => Math.min(2, s + 1))}
            onDismiss={() => setShowOnboarding(false)}
            onApplyTutorialDigit={(digit) => {
              handleCellInputChange(focusedPos.row, focusedPos.col, digit);
            }}
          />
        )}

        {/* Live Linear Equation Inspector Bar */}
        <div
          className={`w-full max-w-2xl mb-3 rounded-xl border px-3.5 py-2.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs font-mono tabular-nums ${
            darkMode
              ? 'bg-[#111827] border-slate-800/90 text-slate-300'
              : 'bg-white border-slate-200 text-slate-700 shadow-2xs'
          }`}
        >
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setDirection('row')}
              className={`inline-flex items-center gap-1.5 px-2 py-1 rounded transition-colors cursor-pointer ${
                direction === 'row'
                  ? darkMode
                    ? 'bg-amber-500/20 text-amber-300 font-semibold'
                    : 'bg-blue-50 text-blue-700 font-semibold'
                  : 'opacity-75 hover:opacity-100'
              }`}
              title="Click or press Tab to focus Horizontal Row traversal"
            >
              <ArrowRight className="w-3.5 h-3.5" />
              <span>R{activeEquationsPreview.rowIndex + 1}:</span>
              <span>{activeEquationsPreview.rowString}</span>
            </button>

            <span className={darkMode ? 'text-slate-700' : 'text-slate-300'}>|</span>

            <button
              type="button"
              onClick={() => setDirection('col')}
              className={`inline-flex items-center gap-1.5 px-2 py-1 rounded transition-colors cursor-pointer ${
                direction === 'col'
                  ? darkMode
                    ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                    : 'bg-emerald-50 text-emerald-700 font-semibold'
                  : 'opacity-75 hover:opacity-100'
              }`}
              title="Click or press Tab to focus Vertical Column traversal"
            >
              <ArrowDown className="w-3.5 h-3.5" />
              <span>C{activeEquationsPreview.colIndex + 1}:</span>
              <span>{activeEquationsPreview.colString}</span>
            </button>
          </div>

          <span className={`text-[11px] ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>
            Linear Left→Right & Top→Bottom
          </span>
        </div>

        {/* Optional Status / Deduction Feedback Banner */}
        {statusBanner && (
          <div
            className={`w-full max-w-2xl mb-3 px-3.5 py-2 rounded-lg border text-xs font-mono flex items-center justify-between ${
              statusBanner.type === 'error'
                ? darkMode
                  ? 'bg-red-950/60 border-red-500/40 text-red-300'
                  : 'bg-red-50 border-red-200 text-red-800'
                : darkMode
                ? 'bg-amber-950/40 border-amber-500/30 text-amber-200'
                : 'bg-blue-50 border-blue-200 text-blue-800'
            }`}
          >
            <span>{statusBanner.message}</span>
            <button
              type="button"
              onClick={() => setStatusBanner(null)}
              className="ml-3 underline opacity-75 hover:opacity-100 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Mathematical Crossword Lattice Board */}
        <div
          className={`p-3 sm:p-6 rounded-2xl border transition-colors ${
            darkMode
              ? 'bg-[#131B2E] border-slate-800 shadow-2xl shadow-black/50'
              : 'bg-white border-slate-200 shadow-xl shadow-slate-200/60'
          }`}
        >
          <div className="flex flex-col items-center">
            {puzzle.cells.map((rowCells, r) => {
              const isRowFocused =
                focusedPos?.row === r &&
                (!showOnboarding || onboardingStep === 0 || onboardingStep === 2);
              const rowStatus = lineStatuses.rowValid[r];

              return (
                <React.Fragment key={`row-group-${r}`}>
                  {/* Number + Horizontal Operator Row */}
                  <div className="flex items-center">
                    {rowCells.map((cell, c) => {
                      const isFocused = focusedPos?.row === r && focusedPos?.col === c;
                      const isColFocused =
                        focusedPos?.col === c &&
                        (!showOnboarding || onboardingStep === 1 || onboardingStep === 2);
                      const isResultCell = r === N - 1 || c === N - 1;
                      const colStatus = lineStatuses.colValid[c];

                      const lineCompleteValid =
                        rowStatus === 'valid' || colStatus === 'valid';
                      const lineCompleteInvalid =
                        rowStatus === 'invalid' || colStatus === 'invalid';

                      // Determine horizontal operator to the right of (r, c)
                      const hasRightOp = c < N - 1;
                      const rightSymbol =
                        c < N - 2
                          ? displayOperatorSymbol(puzzle.rowOps[r][c])
                          : '=';

                      return (
                        <React.Fragment key={`cell-${r}-${c}`}>
                          <div className="relative">
                            {cell.isClue ? (
                              <div
                                onClick={() => {
                                  setFocusedPos({ row: r, col: c });
                                }}
                                className={`${cellDimClass} rounded-xl font-mono font-bold tabular-nums flex items-center justify-center border transition-all duration-150 select-none ${
                                  isRowFocused || isColFocused
                                    ? darkMode
                                      ? 'bg-slate-800/95 border-amber-500/50 text-slate-100'
                                      : 'bg-blue-50/70 border-blue-300 text-slate-900'
                                    : isResultCell
                                    ? darkMode
                                      ? 'bg-slate-900/95 border-slate-700/80 text-amber-300/90'
                                      : 'bg-slate-100 border-slate-300 text-slate-800'
                                    : darkMode
                                    ? 'bg-slate-900/75 border-slate-800 text-slate-300'
                                    : 'bg-slate-100/80 border-slate-200 text-slate-700'
                                }`}
                              >
                                {cell.solution}
                              </div>
                            ) : (
                              <input
                                ref={(el) => {
                                  if (!inputRefs.current[r]) {
                                    inputRefs.current[r] = [];
                                  }
                                  inputRefs.current[r][c] = el;
                                }}
                                type="text"
                                inputMode="numeric"
                                pattern="[0-9]*"
                                maxLength={2}
                                value={cell.userValue}
                                aria-label={`Row ${r + 1} Column ${c + 1} input`}
                                onFocus={() => setFocusedPos({ row: r, col: c })}
                                onClick={() => {
                                  if (focusedPos?.row === r && focusedPos?.col === c) {
                                    setDirection((d) => (d === 'row' ? 'col' : 'row'));
                                  } else {
                                    setFocusedPos({ row: r, col: c });
                                  }
                                }}
                                onChange={(e) =>
                                  handleCellInputChange(r, c, e.target.value)
                                }
                                onKeyDown={(e) => handleCellKeyDown(e, r, c)}
                                className={`${cellDimClass} rounded-xl font-mono font-bold tabular-nums text-center outline-none border-2 transition-all duration-150 cursor-pointer ${
                                  cell.isError || lineCompleteInvalid
                                    ? darkMode
                                      ? 'bg-red-950/60 border-red-500 text-red-200'
                                      : 'bg-red-50 border-red-500 text-red-700'
                                    : isFocused
                                    ? darkMode
                                      ? 'bg-amber-500/20 border-amber-400 text-white ring-2 ring-amber-400/30 scale-[1.03]'
                                      : 'bg-blue-50 border-blue-600 text-blue-950 ring-2 ring-blue-500/25 scale-[1.03]'
                                    : lineCompleteValid
                                    ? darkMode
                                      ? 'bg-emerald-950/35 border-emerald-500/50 text-emerald-300'
                                      : 'bg-emerald-50/70 border-emerald-400 text-emerald-900'
                                    : isRowFocused || isColFocused
                                    ? darkMode
                                      ? 'bg-slate-800/80 border-amber-500/40 text-amber-200'
                                      : 'bg-blue-50/50 border-blue-300 text-blue-900'
                                    : darkMode
                                    ? 'bg-[#0B0F17] border-slate-700 text-slate-100 hover:border-slate-500'
                                    : 'bg-white border-slate-300 text-slate-900 hover:border-slate-400'
                                }`}
                              />
                            )}

                            {/* Subtle badge for hinted cells */}
                            {cell.isHinted && (
                              <span
                                className="absolute top-1 right-1.5 text-[9px] font-mono font-bold text-amber-400 pointer-events-none"
                                title="Revealed via Hint"
                              >
                                H
                              </span>
                            )}
                          </div>

                          {/* Horizontal Operator Connector */}
                          {hasRightOp && (
                            <div
                              className={`${opCellWidthClass} flex items-center justify-center font-mono font-bold select-none transition-colors ${
                                rightSymbol === '='
                                  ? rowStatus === 'valid'
                                    ? 'text-emerald-500'
                                    : rowStatus === 'invalid'
                                    ? 'text-red-500'
                                    : darkMode
                                    ? 'text-amber-400'
                                    : 'text-blue-600'
                                  : isRowFocused
                                  ? darkMode
                                    ? 'text-amber-300'
                                    : 'text-blue-600'
                                  : darkMode
                                  ? 'text-slate-400'
                                  : 'text-slate-500'
                              }`}
                            >
                              {rightSymbol}
                            </div>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </div>

                  {/* Vertical Operator Connector Row between r and r + 1 */}
                  {r < N - 1 && (
                    <div className="flex items-center">
                      {rowCells.map((_, c) => {
                        const isColFocused =
                          focusedPos?.col === c &&
                          (!showOnboarding || onboardingStep === 1 || onboardingStep === 2);
                        const colStatus = lineStatuses.colValid[c];
                        const downSymbol =
                          r < N - 2
                            ? displayOperatorSymbol(puzzle.colOps[r][c])
                            : '=';

                        return (
                          <React.Fragment key={`vop-${r}-${c}`}>
                            <div
                              className={`${cellDimClass.split(' ')[0]} ${
                                cellDimClass.split(' ')[2] || ''
                              } ${opRowHeightClass} flex items-center justify-center font-mono font-bold select-none transition-colors ${
                                downSymbol === '='
                                  ? colStatus === 'valid'
                                    ? 'text-emerald-500'
                                    : colStatus === 'invalid'
                                    ? 'text-red-500'
                                    : darkMode
                                    ? 'text-amber-400'
                                    : 'text-blue-600'
                                  : isColFocused
                                  ? darkMode
                                    ? 'text-emerald-300'
                                    : 'text-emerald-600'
                                  : darkMode
                                  ? 'text-slate-400'
                                  : 'text-slate-500'
                              }`}
                            >
                              {downSymbol}
                            </div>
                            {c < N - 1 && (
                              <div
                                className={`${opCellWidthClass} ${opRowHeightClass}`}
                                aria-hidden="true"
                              />
                            )}
                          </React.Fragment>
                        );
                      })}
                    </div>
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Tactile On-Screen Numpad for fast mouse/touch entry */}
        <div className="mt-4 flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 max-w-xl">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleNumpadPress(digit)}
              className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl font-mono text-sm sm:text-base font-bold border transition-all duration-100 active:scale-95 cursor-pointer ${
                darkMode
                  ? 'bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800 hover:border-slate-700'
                  : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100 shadow-2xs'
              }`}
            >
              {digit}
            </button>
          ))}
          <button
            type="button"
            onClick={() => handleNumpadPress('BACKSPACE')}
            className={`px-3.5 h-10 sm:h-11 rounded-xl font-mono text-xs font-semibold border inline-flex items-center gap-1.5 transition-all duration-100 active:scale-95 cursor-pointer ${
              darkMode
                ? 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100 shadow-2xs'
            }`}
            title="Clear focused cell (Backspace)"
          >
            <Delete className="w-4 h-4" />
            <span>Clear</span>
          </button>
        </div>
      </main>

      {/* Pause / Difficulty & Grid Architecture Modal */}
      {gameState === 'PAUSED' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 px-4">
          <div
            className={`w-full max-w-md rounded-2xl border p-6 shadow-2xl ${
              darkMode
                ? 'bg-[#131B2E] border-slate-800 text-slate-100'
                : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-2xl font-bold">Game Paused</h2>
              <span className="font-mono text-xs text-amber-400">
                Level {level} · Rating {rating}
              </span>
            </div>

            <p
              className={`text-sm mb-5 leading-relaxed ${
                darkMode ? 'text-slate-300' : 'text-slate-600'
              }`}
            >
              Every row (left-to-right) and column (top-to-bottom) evaluates linearly without operator precedence. You can let Adaptive Rating scale the grid automatically or test a specific grid dimension below.
            </p>

            {/* Grid Size Override Selector */}
            <div className="mb-6">
              <label
                className={`block text-xs font-mono mb-2 ${
                  darkMode ? 'text-slate-400' : 'text-slate-500'
                }`}
              >
                Grid Scaling Mode
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: 'Adaptive', val: null },
                  { label: '3×3 Easy', val: 3 },
                  { label: '4×4 Adept', val: 4 },
                  { label: '5×5 Mixed', val: 5 },
                  { label: '6×6 Deep', val: 6 },
                  { label: '7×7 Master', val: 7 },
                ].map((opt) => (
                  <button
                    key={opt.label}
                    type="button"
                    onClick={() => {
                      setOverrideSize(opt.val);
                      startPuzzleLevel(rating, level, opt.val);
                    }}
                    className={`px-3 py-2 rounded-lg font-mono text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                      overrideSize === opt.val
                        ? darkMode
                          ? 'bg-amber-500 border-amber-400 text-slate-950'
                          : 'bg-blue-600 border-blue-600 text-white'
                        : darkMode
                        ? 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-2.5">
              <button
                type="button"
                onClick={() => setGameState('PLAYING')}
                className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                  darkMode
                    ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                    : 'bg-blue-600 text-white hover:bg-blue-500'
                }`}
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Resume Puzzle</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setRating(100);
                  setLevel(1);
                  setOverrideSize(null);
                  startPuzzleLevel(100, 1, null);
                }}
                className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold border transition-colors cursor-pointer ${
                  darkMode
                    ? 'border-slate-700 bg-slate-900 text-slate-300 hover:bg-slate-800'
                    : 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reset to Level 1</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Level Complete / Victory & Adaptive Rating Summary Modal */}
      {gameState === 'ROUND_SUMMARY' && lastRatingResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 px-4">
          <div
            className={`w-full max-w-md rounded-2xl border p-6 shadow-2xl ${
              darkMode
                ? 'bg-[#131B2E] border-slate-800 text-slate-100'
                : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <div className="flex items-center gap-3 mb-4">
              <div
                className={`w-11 h-11 rounded-xl flex items-center justify-center ${
                  darkMode
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                }`}
              >
                <Award className="w-6 h-6" />
              </div>
              <div>
                <div className="text-xs font-mono text-emerald-400 font-semibold">
                  LEVEL {level} COMPLETE · {lastRatingResult.performanceLabel.toUpperCase()}
                </div>
                <h2 className="font-display text-2xl font-bold">
                  Equations Balanced
                </h2>
              </div>
            </div>

            {/* Telemetry Breakdown */}
            <div
              className={`grid grid-cols-3 gap-2.5 p-3.5 rounded-xl border mb-5 font-mono tabular-nums ${
                darkMode
                  ? 'bg-slate-900/90 border-slate-800'
                  : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div>
                <div className="text-[11px] text-slate-400">Solve Time</div>
                <div className="text-base font-bold mt-0.5">
                  {formatTime(elapsedSeconds)}
                </div>
                <div className="text-[10px] text-slate-500">
                  Par {formatTime(puzzle.profile.parTimeSeconds)}
                </div>
              </div>

              <div>
                <div className="text-[11px] text-slate-400">Hints Used</div>
                <div className="text-base font-bold mt-0.5">{hintsUsed}</div>
                <div className="text-[10px] text-slate-500">
                  {hintsUsed === 0 ? 'Unassisted' : 'Assisted'}
                </div>
              </div>

              <div>
                <div className="text-[11px] text-slate-400">Adaptive Rating</div>
                <div className="text-base font-bold mt-0.5 flex items-center gap-1">
                  <span>{lastRatingResult.newRating}</span>
                  <span
                    className={`text-xs ${
                      lastRatingResult.delta > 0
                        ? 'text-emerald-400'
                        : lastRatingResult.delta < 0
                        ? 'text-amber-400'
                        : 'text-slate-400'
                    }`}
                  >
                    ({lastRatingResult.delta >= 0 ? `+${lastRatingResult.delta}` : lastRatingResult.delta})
                  </span>
                </div>
                <div className="text-[10px] text-slate-500 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  <span>Scales Grid</span>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-2.5">
              <button
                type="button"
                onClick={() => {
                  const nextLvl = level + 1;
                  setLevel(nextLvl);
                  startPuzzleLevel(lastRatingResult.newRating, nextLvl, overrideSize);
                }}
                className={`w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                  darkMode
                    ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                    : 'bg-blue-600 text-white hover:bg-blue-500'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>Next Level (Level {level + 1})</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setLevel((l) => l + 1);
                  setGameState('TITLE_MENU');
                }}
                className={`px-4 py-3 rounded-xl text-sm font-semibold border transition-colors cursor-pointer inline-flex items-center justify-center gap-1.5 ${
                  darkMode
                    ? 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800'
                    : 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Home className="w-4 h-4" />
                <span>Title</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
