export type MathOperator = '+' | '-' | '*' | '/';

export interface DifficultyProfile {
  tierName: string;
  gridSize: number; // 3 to 7
  allowedOperators: MathOperator[];
  minValue: number;
  maxOperand: number;
  maxAnswer: number;
  targetBlanks: number;
  parTimeSeconds: number;
}

export interface CellData {
  row: number;
  col: number;
  solution: number;
  isClue: boolean;
  userValue: string;
  isHinted: boolean;
  isError: boolean;
}

export interface MathCrosswordPuzzle {
  id: string;
  level: number;
  ratingAtGeneration: number;
  profile: DifficultyProfile;
  size: number; // N (3 to 7)
  cells: CellData[][];
  /**
   * rowOps[r][c] is the operator between cells[r][c] and cells[r][c+1] for c in 0..size-3.
   * Between cells[r][size-2] and cells[r][size-1] is always '='.
   */
  rowOps: MathOperator[][];
  /**
   * colOps[r][c] is the operator between cells[r][c] and cells[r+1][c] for r in 0..size-3.
   * Between cells[size-2][c] and cells[size-1][c] is always '='.
   */
  colOps: MathOperator[][];
  verifiedSolutionsCount: number;
  generationSteps: number;
}

export interface LogicalDeductionHint {
  row: number;
  col: number;
  axis: 'row' | 'col';
  lineIndex: number;
  value: number;
  explanation: string;
}

export interface RatingAdjustmentResult {
  previousRating: number;
  newRating: number;
  delta: number;
  performanceLabel: string;
  timeRatio: number;
}

/**
 * Computes the difficulty parameters from the player's adaptive rating and level.
 * Level 1 is strictly guaranteed to be 3x3, '+' and '-' only, and single-digit answers (1-9).
 */
export function getDifficultyProfile(
  rating: number,
  level: number,
  overrideGridSize?: number | null
): DifficultyProfile {
  const effectiveRating = level === 1 && !overrideGridSize ? 100 : Math.max(100, rating);

  let gridSize = 3;
  let tierName = 'Initiate';
  let allowedOperators: MathOperator[] = ['+', '-'];
  let maxOperand = 6;
  let maxAnswer = 9;
  let targetBlanks = 4;
  let parTimeSeconds = 45;

  if (effectiveRating < 140) {
    gridSize = 3;
    tierName = 'Initiate';
    allowedOperators = ['+', '-'];
    maxOperand = 6;
    maxAnswer = 9; // Strictly single-digit answers (1-9)
    targetBlanks = level === 1 ? 4 : 5;
    parTimeSeconds = 45;
  } else if (effectiveRating < 200) {
    gridSize = 4;
    tierName = 'Adept';
    allowedOperators = ['+', '-', '*'];
    maxOperand = 8;
    maxAnswer = 24;
    targetBlanks = 7;
    parTimeSeconds = 80;
  } else if (effectiveRating < 270) {
    gridSize = 5;
    tierName = 'Tactician';
    allowedOperators = ['+', '-', '*', '/'];
    maxOperand = 9;
    maxAnswer = 45;
    targetBlanks = 11;
    parTimeSeconds = 130;
  } else if (effectiveRating < 350) {
    gridSize = 6;
    tierName = 'Architect';
    allowedOperators = ['+', '-', '*', '/'];
    maxOperand = 12;
    maxAnswer = 72;
    targetBlanks = 15;
    parTimeSeconds = 190;
  } else {
    gridSize = 7;
    tierName = 'Grandmaster';
    allowedOperators = ['+', '-', '*', '/'];
    maxOperand = 12;
    maxAnswer = 99;
    targetBlanks = 21;
    parTimeSeconds = 260;
  }

  if (overrideGridSize && overrideGridSize >= 3 && overrideGridSize <= 7) {
    gridSize = overrideGridSize;
    if (gridSize === 3) {
      tierName = 'Initiate (3×3)';
      allowedOperators = level === 1 ? ['+', '-'] : ['+', '-'];
      maxOperand = 6;
      maxAnswer = 9;
      targetBlanks = 4;
      parTimeSeconds = 45;
    } else if (gridSize === 4) {
      tierName = 'Adept (4×4)';
      allowedOperators = ['+', '-', '*'];
      maxOperand = 8;
      maxAnswer = 24;
      targetBlanks = 7;
      parTimeSeconds = 80;
    } else if (gridSize === 5) {
      tierName = 'Tactician (5×5)';
      allowedOperators = ['+', '-', '*', '/'];
      maxOperand = 9;
      maxAnswer = 45;
      targetBlanks = 11;
      parTimeSeconds = 130;
    } else if (gridSize === 6) {
      tierName = 'Architect (6×6)';
      allowedOperators = ['+', '-', '*', '/'];
      maxOperand = 12;
      maxAnswer = 72;
      targetBlanks = 15;
      parTimeSeconds = 190;
    } else {
      tierName = 'Grandmaster (7×7)';
      allowedOperators = ['+', '-', '*', '/'];
      maxOperand = 12;
      maxAnswer = 99;
      targetBlanks = 21;
      parTimeSeconds = 260;
    }
  }

  return {
    tierName,
    gridSize,
    allowedOperators,
    minValue: 1,
    maxOperand,
    maxAnswer,
    targetBlanks,
    parTimeSeconds,
  };
}

/**
 * Applies a single binary operation with strict integer arithmetic validation.
 * Returns null if division is not exact or if result <= 0.
 */
export function applyBinaryOp(a: number, op: MathOperator, b: number): number | null {
  if (!Number.isFinite(a) || !Number.isFinite(b) || b <= 0 || a <= 0) return null;
  switch (op) {
    case '+':
      return a + b;
    case '-': {
      const diff = a - b;
      return diff >= 1 ? diff : null;
    }
    case '*':
      return a * b;
    case '/': {
      if (b === 0 || a % b !== 0) return null;
      const quot = a / b;
      return quot >= 1 ? quot : null;
    }
  }
}

/**
 * Evaluates an operand chain strictly left-to-right (or top-to-bottom):
 * (((operands[0] op[0] operands[1]) op[1] operands[2]) ...)
 * Returns null if any intermediate step produces a non-integer or non-positive number.
 */
export function evaluateLinearChain(operands: number[], ops: MathOperator[]): number | null {
  if (operands.length === 0) return null;
  if (ops.length !== operands.length - 1) return null;

  let acc = operands[0];
  if (!Number.isInteger(acc) || acc < 1) return null;

  for (let i = 0; i < ops.length; i++) {
    const nextVal = operands[i + 1];
    if (!Number.isInteger(nextVal) || nextVal < 1) return null;
    const stepResult = applyBinaryOp(acc, ops[i], nextVal);
    if (stepResult === null || !Number.isInteger(stepResult) || stepResult < 1) {
      return null;
    }
    acc = stepResult;
  }

  return acc;
}

/**
 * Formats an equation with explicit left-to-right parenthetical grouping
 * so players can visually inspect the strict linear order of operations.
 */
export function formatLinearEquationString(
  values: (number | string)[],
  ops: MathOperator[]
): string {
  if (values.length < 2) return '';
  const operands = values.slice(0, values.length - 1);
  const result = values[values.length - 1];

  const displayOp = (op: MathOperator) =>
    op === '*' ? '×' : op === '/' ? '÷' : op === '-' ? '−' : '+';

  let expr = `${operands[0]}`;
  for (let i = 0; i < ops.length; i++) {
    const wrapped = i > 0 && ops.length > 1 ? `(${expr})` : expr;
    expr = `${wrapped} ${displayOp(ops[i])} ${operands[i + 1]}`;
  }
  return `${expr} = ${result}`;
}

/**
 * Given an equation of length N (N-1 operands + 1 result at index N-1)
 * where EXACTLY ONE position `unknownIdx` is null and all other N-1 positions are positive integers,
 * algebraically computes the unique positive integer value for `unknownIdx` under strict linear left-to-right rules.
 * Returns null if no positive integer can satisfy the equation.
 */
export function solveSingleUnknownInLine(
  lineValues: (number | null)[],
  ops: MathOperator[]
): number | null {
  const n = lineValues.length;
  let unknownIdx = -1;
  let unknownCount = 0;

  for (let i = 0; i < n; i++) {
    if (lineValues[i] === null) {
      unknownIdx = i;
      unknownCount++;
      if (unknownCount > 1) return null;
    }
  }

  if (unknownCount !== 1) return null;

  // Case 1: The unknown is the result cell at n - 1
  if (unknownIdx === n - 1) {
    const operands = lineValues.slice(0, n - 1) as number[];
    return evaluateLinearChain(operands, ops);
  }

  // Case 2: The unknown is an operand at index u in 0 .. n - 2
  const targetResult = lineValues[n - 1];
  if (targetResult === null || targetResult < 1) return null;

  // Peel known operands from the right (from index n - 2 down to unknownIdx + 1)
  let requiredPrefix = targetResult;
  for (let i = n - 2; i > unknownIdx; i--) {
    const rightVal = lineValues[i]!;
    const op = ops[i - 1];
    // We have: (prevPrefix) op rightVal = requiredPrefix
    switch (op) {
      case '+':
        requiredPrefix = requiredPrefix - rightVal;
        break;
      case '-':
        requiredPrefix = requiredPrefix + rightVal;
        break;
      case '*':
        if (rightVal <= 0 || requiredPrefix % rightVal !== 0) return null;
        requiredPrefix = requiredPrefix / rightVal;
        break;
      case '/':
        requiredPrefix = requiredPrefix * rightVal;
        break;
    }
    if (!Number.isInteger(requiredPrefix) || requiredPrefix < 1) return null;
  }

  // Now the prefix chain [0 .. unknownIdx] must evaluate to `requiredPrefix`
  let candidate: number | null = null;
  if (unknownIdx === 0) {
    candidate = requiredPrefix;
  } else {
    const knownPrefixOperands = lineValues.slice(0, unknownIdx) as number[];
    const knownPrefixOps = ops.slice(0, unknownIdx - 1);
    const leftAcc = evaluateLinearChain(knownPrefixOperands, knownPrefixOps);
    if (leftAcc === null) return null;

    const op = ops[unknownIdx - 1];
    // We have: leftAcc op candidate = requiredPrefix
    switch (op) {
      case '+':
        candidate = requiredPrefix - leftAcc;
        break;
      case '-':
        candidate = leftAcc - requiredPrefix;
        break;
      case '*':
        if (leftAcc <= 0 || requiredPrefix % leftAcc !== 0) return null;
        candidate = requiredPrefix / leftAcc;
        break;
      case '/':
        if (requiredPrefix <= 0 || leftAcc % requiredPrefix !== 0) return null;
        candidate = leftAcc / requiredPrefix;
        break;
    }
  }

  if (candidate === null || !Number.isInteger(candidate) || candidate < 1) {
    return null;
  }

  // Final forward check to verify exactness
  const verifyOperands: number[] = [];
  for (let i = 0; i < n - 1; i++) {
    verifyOperands.push(i === unknownIdx ? candidate : (lineValues[i] as number));
  }
  const actualResult = evaluateLinearChain(verifyOperands, ops);
  if (actualResult !== targetResult) return null;

  return candidate;
}

/**
 * Checks whether a complete line of numbers satisfies its equation.
 */
export function isCompleteLineValid(values: number[], ops: MathOperator[]): boolean {
  if (values.length < 3) return false;
  const operands = values.slice(0, values.length - 1);
  const expectedResult = values[values.length - 1];
  const actual = evaluateLinearChain(operands, ops);
  return actual !== null && actual === expectedResult;
}

/**
 * Backtracking solver with constraint propagation (unit-unknown elimination)
 * and bounded step budget to guarantee zero infinite loops.
 * Counts up to `maxSolutions` (default 2) to verify uniqueness (solutions === 1).
 */
export function countPuzzleSolutions(
  initialBoard: (number | null)[][],
  rowOps: MathOperator[][],
  colOps: MathOperator[][],
  maxDomainValue: number,
  maxSolutions = 2,
  maxSteps = 8000
): { solutions: number; steps: number; timedOut: boolean } {
  const size = initialBoard.length;
  let steps = 0;
  let timedOut = false;

  function cloneBoard(b: (number | null)[][]): (number | null)[][] {
    return b.map((row) => [...row]);
  }

  function getColValues(b: (number | null)[][], c: number): (number | null)[] {
    const arr: (number | null)[] = [];
    for (let r = 0; r < size; r++) arr.push(b[r][c]);
    return arr;
  }

  function getColOpsForCol(c: number): MathOperator[] {
    const arr: MathOperator[] = [];
    for (let r = 0; r < size - 2; r++) arr.push(colOps[r][c]);
    return arr;
  }

  /**
   * Propagates all rows and columns that have 0 or 1 unknowns.
   * Returns false if a contradiction is discovered.
   */
  function propagate(board: (number | null)[][]): boolean {
    let changed = true;
    while (changed) {
      changed = false;
      steps++;
      if (steps > maxSteps) {
        timedOut = true;
        return false;
      }

      // Check rows
      for (let r = 0; r < size; r++) {
        let nulls = 0;
        let nullCol = -1;
        for (let c = 0; c < size; c++) {
          if (board[r][c] === null) {
            nulls++;
            nullCol = c;
          }
        }

        if (nulls === 0) {
          if (!isCompleteLineValid(board[r] as number[], rowOps[r])) {
            return false;
          }
        } else if (nulls === 1) {
          const deduced = solveSingleUnknownInLine(board[r], rowOps[r]);
          if (deduced === null || deduced < 1 || deduced > maxDomainValue) {
            return false;
          }
          board[r][nullCol] = deduced;
          changed = true;
        }
      }

      // Check columns
      for (let c = 0; c < size; c++) {
        let nulls = 0;
        let nullRow = -1;
        for (let r = 0; r < size; r++) {
          if (board[r][c] === null) {
            nulls++;
            nullRow = r;
          }
        }

        const colValues = getColValues(board, c);
        const cOps = getColOpsForCol(c);

        if (nulls === 0) {
          if (!isCompleteLineValid(colValues as number[], cOps)) {
            return false;
          }
        } else if (nulls === 1) {
          const deduced = solveSingleUnknownInLine(colValues, cOps);
          if (deduced === null || deduced < 1 || deduced > maxDomainValue) {
            return false;
          }
          board[nullRow][c] = deduced;
          changed = true;
        }
      }
    }
    return true;
  }

  let solutionsFound = 0;

  function search(board: (number | null)[][]): void {
    if (solutionsFound >= maxSolutions || timedOut) return;

    if (!propagate(board)) return;

    // Find the remaining unknown cell with Minimum Remaining Values (most constrained row+col)
    let bestR = -1;
    let bestC = -1;
    let bestScore = 999;

    const rowUnknowns = new Array(size).fill(0);
    const colUnknowns = new Array(size).fill(0);

    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (board[r][c] === null) {
          rowUnknowns[r]++;
          colUnknowns[c]++;
        }
      }
    }

    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (board[r][c] === null) {
          const score = Math.min(rowUnknowns[r], colUnknowns[c]) * 10 + (rowUnknowns[r] + colUnknowns[c]);
          if (score < bestScore) {
            bestScore = score;
            bestR = r;
            bestC = c;
          }
        }
      }
    }

    // No unknowns left -> valid complete solution found!
    if (bestR === -1) {
      solutionsFound++;
      return;
    }

    // Branch over candidate integers for (bestR, bestC)
    // Prefer smaller operand range if not in result row/col
    const isResultSlot = bestR === size - 1 || bestC === size - 1;
    const upperBound = isResultSlot ? maxDomainValue : Math.min(maxDomainValue, 15);

    for (let val = 1; val <= upperBound; val++) {
      if (solutionsFound >= maxSolutions || timedOut) return;
      steps++;
      if (steps > maxSteps) {
        timedOut = true;
        return;
      }

      const nextBoard = cloneBoard(board);
      nextBoard[bestR][bestC] = val;
      search(nextBoard);
    }
  }

  search(cloneBoard(initialBoard));
  return { solutions: solutionsFound, steps, timedOut };
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function shuffleArray<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

/**
 * Generates a complete, valid N x N solution matrix and operators where:
 * - Every row r in 0..N-1 satisfies its left-to-right equation.
 * - Every col c in 0..N-1 satisfies its top-to-bottom equation.
 * - The bottom-right corner (N-1, N-1) simultaneously satisfies both the bottom row and rightmost column.
 */
function generateValidGridSolution(profile: DifficultyProfile): {
  grid: number[][];
  rowOps: MathOperator[][];
  colOps: MathOperator[][];
} | null {
  const N = profile.gridSize;
  const opsPool = profile.allowedOperators;
  const maxOp = profile.maxOperand;
  const maxAns = profile.maxAnswer;

  const grid: number[][] = Array.from({ length: N }, () => new Array(N).fill(1));
  const rowOps: MathOperator[][] = Array.from({ length: N }, () => new Array(N - 2).fill('+'));
  const colOps: MathOperator[][] = Array.from({ length: N - 2 }, () => new Array(N).fill('+'));

  // Track vertical running accumulators for columns 0 .. N-2
  const colAcc: number[] = new Array(N - 1).fill(0);

  // Fill rows 0 .. N-2 and cols 0 .. N-2
  for (let r = 0; r < N - 1; r++) {
    let rowAcc = 0;
    for (let c = 0; c < N - 1; c++) {
      // Leave (N-2, N-2) for intersection matching below
      if (r === N - 2 && c === N - 2) continue;

      const candidates = shuffleArray(
        Array.from({ length: maxOp }, (_, idx) => idx + 1)
      );

      let placed = false;

      if (r === 0 && c === 0) {
        const val = candidates[0];
        grid[0][0] = val;
        rowAcc = val;
        colAcc[0] = val;
        placed = true;
      } else if (r === 0 && c > 0) {
        const shuffledRowOps = shuffleArray(opsPool);
        for (const rOp of shuffledRowOps) {
          for (const val of candidates) {
            const nextRowAcc = applyBinaryOp(rowAcc, rOp, val);
            // Keep intermediate values reasonable so future operations have headroom
            const maxInter = c === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
            if (nextRowAcc !== null && nextRowAcc >= 1 && nextRowAcc <= maxInter) {
              grid[0][c] = val;
              rowOps[0][c - 1] = rOp;
              rowAcc = nextRowAcc;
              colAcc[c] = val;
              placed = true;
              break;
            }
          }
          if (placed) break;
        }
      } else if (r > 0 && c === 0) {
        const shuffledColOps = shuffleArray(opsPool);
        for (const cOp of shuffledColOps) {
          for (const val of candidates) {
            const nextColAcc = applyBinaryOp(colAcc[0], cOp, val);
            const maxInter = r === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
            if (nextColAcc !== null && nextColAcc >= 1 && nextColAcc <= maxInter) {
              grid[r][0] = val;
              colOps[r - 1][0] = cOp;
              rowAcc = val;
              colAcc[0] = nextColAcc;
              placed = true;
              break;
            }
          }
          if (placed) break;
        }
      } else {
        // Both r > 0 and c > 0
        const shuffledRowOps = shuffleArray(opsPool);
        const shuffledColOps = shuffleArray(opsPool);
        for (const rOp of shuffledRowOps) {
          for (const cOp of shuffledColOps) {
            for (const val of candidates) {
              const nextRowAcc = applyBinaryOp(rowAcc, rOp, val);
              const nextColAcc = applyBinaryOp(colAcc[c], cOp, val);
              const maxRowInter = c === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
              const maxColInter = r === N - 2 ? maxAns : Math.max(maxAns, maxOp * 2);
              if (
                nextRowAcc !== null &&
                nextRowAcc >= 1 &&
                nextRowAcc <= maxRowInter &&
                nextColAcc !== null &&
                nextColAcc >= 1 &&
                nextColAcc <= maxColInter
              ) {
                grid[r][c] = val;
                rowOps[r][c - 1] = rOp;
                colOps[r - 1][c] = cOp;
                rowAcc = nextRowAcc;
                colAcc[c] = nextColAcc;
                placed = true;
                break;
              }
            }
            if (placed) break;
          }
          if (placed) break;
        }
      }

      if (!placed) return null;
    }

    if (r < N - 2) {
      grid[r][N - 1] = rowAcc;
    }
  }

  // Finalize column results for cols 0 .. N-3
  for (let c = 0; c < N - 2; c++) {
    grid[N - 1][c] = colAcc[c];
  }

  // Now compute running prefix of bottom row (row N-1) for cols 0 .. N-3
  // and running prefix of rightmost column (col N-1) for rows 0 .. N-3
  // Then pick grid[N-2][N-2] and the remaining operators so they meet at grid[N-1][N-1]!
  const bottomPrefixOpsTries = 12;
  for (let t = 0; t < bottomPrefixOpsTries; t++) {
    // Pick operators for bottom row up to col N-3 and right col up to row N-3
    let bottomAcc = grid[N - 1][0];
    let bottomOk = true;
    for (let c = 1; c < N - 2; c++) {
      const shuffled = shuffleArray(opsPool);
      let stepFound = false;
      for (const op of shuffled) {
        const res = applyBinaryOp(bottomAcc, op, grid[N - 1][c]);
        if (res !== null && res >= 1 && res <= maxAns * 2) {
          rowOps[N - 1][c - 1] = op;
          bottomAcc = res;
          stepFound = true;
          break;
        }
      }
      if (!stepFound) {
        bottomOk = false;
        break;
      }
    }
    if (!bottomOk) continue;

    let rightAcc = grid[0][N - 1];
    let rightOk = true;
    for (let r = 1; r < N - 2; r++) {
      const shuffled = shuffleArray(opsPool);
      let stepFound = false;
      for (const op of shuffled) {
        const res = applyBinaryOp(rightAcc, op, grid[r][N - 1]);
        if (res !== null && res >= 1 && res <= maxAns * 2) {
          colOps[r - 1][N - 1] = op;
          rightAcc = res;
          stepFound = true;
          break;
        }
      }
      if (!stepFound) {
        rightOk = false;
        break;
      }
    }
    if (!rightOk) continue;

    // Prefix of row N-2 up to col N-3:
    const rowN2PrefixOperands = grid[N - 2].slice(0, N - 2);
    const rowN2PrefixOps = rowOps[N - 2].slice(0, N - 3);
    const rowN2Acc = evaluateLinearChain(rowN2PrefixOperands, rowN2PrefixOps);
    const colN2Acc = colAcc[N - 2];

    if (rowN2Acc === null) continue;

    // Now test candidate values for grid[N-2][N-2] and operators so that
    // bottom row result === rightmost column result === grid[N-1][N-1] <= maxAns
    const valCandidates = shuffleArray(Array.from({ length: maxOp }, (_, i) => i + 1));
    const shuffledOps1 = shuffleArray(opsPool);
    const shuffledOps2 = shuffleArray(opsPool);

    for (const val of valCandidates) {
      for (const opR of shuffledOps1) {
        const rN2Result = applyBinaryOp(rowN2Acc, opR, val);
        if (rN2Result === null || rN2Result < 1 || rN2Result > maxAns) continue;

        for (const opC of shuffledOps2) {
          const cN2Result = applyBinaryOp(colN2Acc, opC, val);
          if (cN2Result === null || cN2Result < 1 || cN2Result > maxAns) continue;

          // Now check if (bottomAcc [opBottomLast] cN2Result) === (rightAcc [opRightLast] rN2Result)
          for (const opBottomLast of shuffledOps1) {
            const cornerFromRow = applyBinaryOp(bottomAcc, opBottomLast, cN2Result);
            if (cornerFromRow === null || cornerFromRow < 1 || cornerFromRow > maxAns) continue;

            for (const opRightLast of shuffledOps2) {
              const cornerFromCol = applyBinaryOp(rightAcc, opRightLast, rN2Result);
              if (cornerFromCol === cornerFromRow) {
                grid[N - 2][N - 2] = val;
                rowOps[N - 2][N - 3] = opR;
                colOps[N - 3][N - 2] = opC;
                grid[N - 2][N - 1] = rN2Result;
                grid[N - 1][N - 2] = cN2Result;
                rowOps[N - 1][N - 3] = opBottomLast;
                colOps[N - 3][N - 1] = opRightLast;
                grid[N - 1][N - 1] = cornerFromRow;
                return { grid, rowOps, colOps };
              }
            }
          }
        }
      }
    }
  }

  return null;
}

/**
 * Deterministic safe fallback generator that guarantees a valid grid in O(N^2) time
 * if random sampling hits rare constraints, ensuring zero infinite loops.
 */
function generateDeterministicFallbackGrid(profile: DifficultyProfile): {
  grid: number[][];
  rowOps: MathOperator[][];
  colOps: MathOperator[][];
} {
  const N = profile.gridSize;
  const grid: number[][] = Array.from({ length: N }, () => new Array(N).fill(1));
  const rowOps: MathOperator[][] = Array.from({ length: N }, () => new Array(N - 2).fill('+'));
  const colOps: MathOperator[][] = Array.from({ length: N - 2 }, () => new Array(N).fill('+'));

  for (let r = 0; r < N - 1; r++) {
    let rSum = 0;
    for (let c = 0; c < N - 1; c++) {
      const val = ((r + c) % 2) + 1;
      grid[r][c] = val;
      rSum += val;
    }
    grid[r][N - 1] = rSum;
  }

  for (let c = 0; c < N; c++) {
    let cSum = 0;
    for (let r = 0; r < N - 1; r++) {
      cSum += grid[r][c];
    }
    grid[N - 1][c] = cSum;
  }

  return { grid, rowOps, colOps };
}

/**
 * Main procedural puzzle generator.
 * 1. Computes difficulty profile from player rating & level.
 * 2. Generates a valid N x N mathematical crossword grid.
 * 3. Removes clues iteratively while running the backtracking uniqueness validator
 *    to guarantee EVERY generated puzzle has EXACTLY ONE unique logical solution.
 */
export function generateMathCrossword(
  rating: number,
  level: number,
  overrideGridSize?: number | null
): MathCrosswordPuzzle {
  const profile = getDifficultyProfile(rating, level, overrideGridSize);
  const N = profile.gridSize;

  let generated: {
    grid: number[][];
    rowOps: MathOperator[][];
    colOps: MathOperator[][];
  } | null = null;

  const MAX_GRID_ATTEMPTS = 60;
  for (let attempt = 0; attempt < MAX_GRID_ATTEMPTS; attempt++) {
    generated = generateValidGridSolution(profile);
    if (generated) break;
  }

  if (!generated) {
    generated = generateDeterministicFallbackGrid(profile);
  }

  const { grid, rowOps, colOps } = generated;

  // Start with all cells filled, then dig out blanks while verifying uniqueness via backtracking
  const boardState: (number | null)[][] = grid.map((row) => [...row]);

  // Create candidate list of coordinates to dig out
  const allCoords: [number, number][] = [];
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      allCoords.push([r, c]);
    }
  }

  const shuffledCoords = shuffleArray(allCoords);
  let blanksCreated = 0;
  let totalSolverSteps = 0;

  // On Level 1, ensure the intersection cell (0, 1) or (1, 1) is dug out first for the interactive onboarding tutorial
  if (level === 1 && N === 3) {
    const tutorialTarget: [number, number] = [0, 1];
    const idx = shuffledCoords.findIndex(
      ([r, c]) => r === tutorialTarget[0] && c === tutorialTarget[1]
    );
    if (idx > 0) {
      const [item] = shuffledCoords.splice(idx, 1);
      shuffledCoords.unshift(item);
    }
  }

  for (const [r, c] of shuffledCoords) {
    if (blanksCreated >= profile.targetBlanks) break;

    // Never empty an entire row or entire column completely (keep at least 1 anchor per line)
    const rowRemainingClues = boardState[r].filter((v) => v !== null).length;
    let colRemainingClues = 0;
    for (let rr = 0; rr < N; rr++) {
      if (boardState[rr][c] !== null) colRemainingClues++;
    }
    if (rowRemainingClues <= 1 || colRemainingClues <= 1) {
      continue;
    }

    const backup = boardState[r][c];
    boardState[r][c] = null;

    const validation = countPuzzleSolutions(
      boardState,
      rowOps,
      colOps,
      profile.maxAnswer,
      2,
      5000
    );
    totalSolverSteps += validation.steps;

    if (validation.solutions === 1 && !validation.timedOut) {
      blanksCreated++;
    } else {
      // Restore clue to preserve unique solution invariant
      boardState[r][c] = backup;
    }
  }

  // Final verification pass
  const finalCheck = countPuzzleSolutions(
    boardState,
    rowOps,
    colOps,
    profile.maxAnswer,
    2,
    8000
  );
  totalSolverSteps += finalCheck.steps;

  const cells: CellData[][] = [];
  for (let r = 0; r < N; r++) {
    const rowCells: CellData[] = [];
    for (let c = 0; c < N; c++) {
      const isClue = boardState[r][c] !== null;
      rowCells.push({
        row: r,
        col: c,
        solution: grid[r][c],
        isClue,
        userValue: isClue ? String(grid[r][c]) : '',
        isHinted: false,
        isError: false,
      });
    }
    cells.push(rowCells);
  }

  return {
    id: `puzzle-${level}-${Date.now()}-${randomInt(100, 999)}`,
    level,
    ratingAtGeneration: rating,
    profile,
    size: N,
    cells,
    rowOps,
    colOps,
    verifiedSolutionsCount: finalCheck.solutions,
    generationSteps: totalSolverSteps,
  };
}

/**
 * Finds the clearest next logical step for the player (a row or column with 1 remaining blank)
 * so hints teach the linear crossword deduction rather than just dumping numbers.
 */
export function findLogicalDeductionHint(
  puzzle: MathCrosswordPuzzle,
  focusedPos: { row: number; col: number } | null
): LogicalDeductionHint | null {
  const N = puzzle.size;

  // Build current effective board using solution values for already-correct cells and clues
  const currentBoard: (number | null)[][] = puzzle.cells.map((row) =>
    row.map((cell) => {
      if (cell.isClue) return cell.solution;
      const parsed = parseInt(cell.userValue, 10);
      if (parsed === cell.solution) return cell.solution;
      return null;
    })
  );

  // First check if any row has exactly 1 unknown
  for (let r = 0; r < N; r++) {
    const unknowns: number[] = [];
    for (let c = 0; c < N; c++) {
      if (currentBoard[r][c] === null) unknowns.push(c);
    }
    if (unknowns.length === 1) {
      const targetCol = unknowns[0];
      const cell = puzzle.cells[r][targetCol];
      const eqPreview = formatLinearEquationString(
        puzzle.cells[r].map((cl, idx) => (idx === targetCol ? '?' : cl.solution)),
        puzzle.rowOps[r]
      );
      return {
        row: r,
        col: targetCol,
        axis: 'row',
        lineIndex: r,
        value: cell.solution,
        explanation: `Row ${r + 1} has one unknown left: ${eqPreview} → ? = ${cell.solution}`,
      };
    }
  }

  // Next check if any column has exactly 1 unknown
  for (let c = 0; c < N; c++) {
    const unknowns: number[] = [];
    for (let r = 0; r < N; r++) {
      if (currentBoard[r][c] === null) unknowns.push(r);
    }
    if (unknowns.length === 1) {
      const targetRow = unknowns[0];
      const cell = puzzle.cells[targetRow][c];
      const colOpsArr: MathOperator[] = [];
      for (let rr = 0; rr < N - 2; rr++) colOpsArr.push(puzzle.colOps[rr][c]);
      const eqPreview = formatLinearEquationString(
        puzzle.cells.map((rowArr, idx) => (idx === targetRow ? '?' : rowArr[c].solution)),
        colOpsArr
      );
      return {
        row: targetRow,
        col: c,
        axis: 'col',
        lineIndex: c,
        value: cell.solution,
        explanation: `Column ${c + 1} has one unknown left: ${eqPreview} → ? = ${cell.solution}`,
      };
    }
  }

  // Fallback: if focused cell is unsolved, reveal it; otherwise reveal first unsolved cell
  if (focusedPos) {
    const fCell = puzzle.cells[focusedPos.row]?.[focusedPos.col];
    if (fCell && !fCell.isClue && parseInt(fCell.userValue, 10) !== fCell.solution) {
      return {
        row: fCell.row,
        col: fCell.col,
        axis: 'row',
        lineIndex: fCell.row,
        value: fCell.solution,
        explanation: `Intersection at Row ${fCell.row + 1}, Col ${fCell.col + 1} resolves to ${fCell.solution}.`,
      };
    }
  }

  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      const cell = puzzle.cells[r][c];
      if (!cell.isClue && parseInt(cell.userValue, 10) !== cell.solution) {
        return {
          row: r,
          col: c,
          axis: 'row',
          lineIndex: r,
          value: cell.solution,
          explanation: `Intersection at Row ${r + 1}, Col ${c + 1} resolves to ${cell.solution}.`,
        };
      }
    }
  }

  return null;
}

/**
 * Adaptive Rating Calculator:
 * Fast completion with zero hints increases rating significantly (+35 to +55).
 * Moderate completion or 1 hint scales moderately (+12 to +25).
 * Slow completion or multiple hints maintains or slightly lowers rating (-12 to +5, clamped >= 100).
 */
export function calculateRatingAdjustment(
  currentRating: number,
  elapsedSeconds: number,
  parTimeSeconds: number,
  hintsUsed: number,
  errorsMade: number
): RatingAdjustmentResult {
  const safeElapsed = Math.max(1, elapsedSeconds);
  const timeRatio = safeElapsed / parTimeSeconds;

  let delta = 0;
  let performanceLabel = 'Steady Solve';

  if (hintsUsed === 0 && errorsMade === 0 && timeRatio <= 0.65) {
    delta = 50;
    performanceLabel = 'Flawless Blitz';
  } else if (hintsUsed === 0 && timeRatio <= 1.0) {
    delta = Math.max(32, Math.round(45 - errorsMade * 5));
    performanceLabel = 'Optimal Mastery';
  } else if (hintsUsed === 0 && timeRatio <= 1.5) {
    delta = Math.max(16, Math.round(26 - errorsMade * 4));
    performanceLabel = 'Clean Deduction';
  } else if (hintsUsed === 1 && timeRatio <= 1.3) {
    delta = 10;
    performanceLabel = 'Assisted Solve';
  } else if (hintsUsed <= 2 && timeRatio <= 1.8) {
    delta = 0;
    performanceLabel = 'Rating Maintained';
  } else {
    delta = -Math.min(15, hintsUsed * 6 + (timeRatio > 2 ? 6 : 0));
    performanceLabel = 'Adaptive Calibration';
  }

  const newRating = Math.max(100, currentRating + delta);
  return {
    previousRating: currentRating,
    newRating,
    delta: newRating - currentRating,
    performanceLabel,
    timeRatio,
  };
}
